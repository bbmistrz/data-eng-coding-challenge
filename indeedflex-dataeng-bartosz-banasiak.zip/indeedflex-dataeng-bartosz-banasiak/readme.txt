1. It is medium complex algorithm

2. Use columnar data storage format, eg. Parquet. This type of file is design for fast read huge files

3. Couple of possibilities :

- As in point two use different file format

- challenge can be also resolve using SQL analytical functions (over, partition, lead , etc)

- As in this task we have clear grouping by worker, then huge file can be split into smaller chunks. After such operation we can parallel process and combine result

- Additionally we can create additional performance tricks to fasten up work. For example in Oracle database create indexes and partitions. In Snowflake clustering keys and use power of ‘scaling out’ process.

- Additional quantity check should be implemented. For example what to do with blanks, N/As, wrong formats, etc.   