import pandas as pnd

max_days = 6

def continuity(row,nums):
    if row['date_diff'] < nums and row['diff_emp_flag'] ==0 and row['diff_role_flag'] ==0 :
        val = 1
    else:
        val = 0
    return val

my_table = pnd.read_csv(r'C:\Users\barto\Downloads\worker_activity.csv')
#my_table = pnd.read_csv('https://github.com/Syft-Application/data-eng-coding-challenge/blob/main/worker_activity.csv')



my_table['Date']=  pnd.to_datetime(my_table['Date'])

my_table = my_table.sort_values(['Worker', 'Date'], ascending=(True, True))

my_table['previous_date'] = my_table.groupby('Worker')['Date'].shift().fillna(my_table['Date'])
my_table['date_diff'] = ( my_table['Date'] - my_table['previous_date']).dt.total_seconds()/60/60/24

my_table['diff_emp_flag'] = my_table.groupby('Worker')['Employer'].shift().fillna(my_table['Employer']) - my_table['Employer']
my_table['diff_role_flag'] = my_table.groupby('Worker')['Role'].shift().fillna(my_table['Role']) - my_table['Role']

my_table['continuity_count'] = my_table.apply(continuity,axis=1,args=(max_days,))

result = my_table.groupby(['Worker'])['continuity_count'].sum().reset_index()
result = result.sort_values(['continuity_count'], ascending = False)

result.to_csv('result.csv',index=False)



print(my_table)
print(result)

